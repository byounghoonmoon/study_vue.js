<template>
  <div>
    <div class="header">
      <h1 class="header Text">자동차 정보 - Block-Chain</h1>
        <ul>
          <li>
            <a href="#" @click="changeMenu('AuthUser')">사용자 인증</a>
          </li>
          <li>
            <a href="#" @click="changeMenu('ApplyAccident')">사고접수 신청</a>
          </li>
          <li>
            <a href="#" @click="changeMenu('RequestRepair')">수리 요청</a>
          </li>
          <li>
            <a href="#" @click="changeMenu('ApplyInsurance')">수리비 청구</a>
          </li>
          <li>
            <a href="#" @click="changeMenu('ApplyRepairFeeList')">수리비 청구 목록</a>
          </li>
          <li>
            <a href="#" @click="changeMenu('PaymentInsurance')">보험금 지급</a>
          </li>
        </ul>
    </div>
    <div class="container">
      <keep-alive >
        <component v-bind:is="currentView"></component>
      </keep-alive>
    </div>

    <hello-metamask/>
  </div>
</template>



<script>
import AuthUser from './components/AuthUser.vue'
import ApplyAccident from './components/ApplyAccident.vue'
import RequestRepair from './components/RequestRepair.vue'
import ApplyInsurance from './components/ApplyInsurance.vue'
import ApplyRepairFeeList from './components/ApplyRepairFeeList.vue'
import PaymentInsurance from './components/PaymentInsurance.vue'
import HelloMetamask from './components/hello-metamask.vue'

export default {
  name: 'App',
  beforeCreate () {
    console.log('■ Before Create : registerWeb3 Action dispatched from App.vue')
    this.$store.dispatch('registerWeb3')
  },
  components : {  HelloMetamask,AuthUser,ApplyAccident, RequestRepair, ApplyInsurance, ApplyRepairFeeList,PaymentInsurance},
  data() {
    return { currentView : 'ApplyAccident' }
  },
  methods : {
    changeMenu(view) {
      this.currentView = view;
    }
  },
  mounted () {
    console.log('■ Mounted : dispatching getContractInstance')
    this.$store.dispatch('getContractInstance')
  }
}
</script>
<style scoped>
.header { padding: 10px 0px 0px 0px; text-align: center;}
.headerText { padding: 0px 20px 0px 20px; } 
ul { list-style-type: none; margin: 0; padding: 0;
    overflow: hidden;  }
li { float: left; }
li a { display: block;  text-align: center;
    padding: 14px 16px; text-decoration: none;  }
li a:hover { background-color: aqua; color:black; }

</style>
