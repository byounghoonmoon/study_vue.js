// 1. test 작성 전, 배포 후 테스트를 위해 
//    ganache 로컬네트워크에 contract을 배포한다

const assert = require('assert');
const ganache = require('ganache-cli');
const Web3 = require('web3');   
// 어떤 네트워크 provider를 사용할건지 정의
// 로컬 ganache 네트워크를 사용할 예정이므로 ganache.provider 설정
// 실제 작업시에는 Ropsten 또는 Main 네트웍으로 변경해서 가능.
//const web3 = new Web3(ganache.provider({gasLimit: 8000000000000000})); 
//const web3 = new Web3(ganache.provider()); 
const web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:7545'));

// compiled된 코드에서 bytecode, interface 등을 가져오기 위한 부분.(compile.js파일)
// const compiled_code = require('../compile'); 
// console.log(compiled_code);
// const bytecode = compiled_code.bytecode;
// const interface= compiled_code.interface;
// const {bytecode, interface} = compiled_code;

const {bytecode, interface} = require('../compile');

// console.log(bytecode);
// console.log(interface);

let accounts;
let carhub;

// async : await 함수가 async함수이기에 async라고 선언하줌.
beforeEach(async () => {
    // 계정을 가져와서 정보를 넣어둔다.
    accounts = await web3.eth.getAccounts();        

    // code를 deploy한다.(ganache local network)
    //web3.eth.Contract("배포하고자 하는 컴파일된 contract의 interface");
    //        .deploy({data: "컴파일된 bytecode", argument: []);
    //        .send({from: "누가 보내는지", gas: "가스비"});
    // Contract가 instance를 리턴하기에 new 선언
    carhub = await new web3.eth.Contract(JSON.parse(interface))
            .deploy({data: bytecode})
            .send({from: accounts[0], gas: "4500000"});

    // console.log(accounts);
    // console.log(carhub);
});

// CarHub에 대한 테스트를 정의(실제 mocha에서 test코드 수행하는 부분)
describe('CarHub', () => {
    it('deploys a contract', () => {
        assert.ok(carhub.options.address);
    });

    // async 와 await 한쌍..
    it('default getUserCount: ', async () => {
        // getter function getUser(_id)
        // promise 객체를 리턴하므로 await (async) 함수 사용
        // async 인데, sync하게 수행되게하기 위해 await 사용
        // await하면 결과가 리턴될때까지 대기..
        // view, pure 함수는 단순호출개념이므로 call() 사용
        const result = await carhub.methods.getUserCount().call();
        //assert.equal("실제값","기대값");
        assert.equal(result, 0);
    });

    // setter함수는 거래처럼 gas fee가발생하기에 send() 사용
    it('authUser: ', async () => {
        await carhub.methods.authUser('P001','이고객','I001','삼성화재')
                    .send({from: accounts[0], gas:1000000});
        const result = await carhub.methods.getUserCount().call();
        assert.equal(result, 1);
    });

    // 사용자여부
    it('isUser: ', async () => {
        await carhub.methods.authUser('P001','이고객','I001','삼성화재')
                    .send({from: accounts[0], gas:1000000});
        const isuser = await carhub.methods.isUser().call({from: accounts[0]});
        assert.equal(isuser, true);
    });

    // 사용자 조회
    it('getUser: ', async () => {
        await carhub.methods.authUser('P001','이고객','I001','삼성화재')
                    .send({from: accounts[0], gas:1000000});
        const userinfo = await carhub.methods.getUser(0).call();
        assert.equal(userinfo[1], "P001");
    });

    // 사고접수
    it('accRequest: ', async() => {
        await carhub.methods.authUser('P001','이고객','I001','삼성화재')
                    .send({from: accounts[0], gas:1000000});
        await carhub.methods.accRequest('11가1234','010-111-1111','I001','삼성화재','사고내용...','20181101')
                    .send({from: accounts[0], gas:1000000});
        const accReqNo = await carhub.methods.getAccReqNo().call();
        console.log('accRequest: ', accReqNo);
        assert.ok(accReqNo);
    })

    // 수리요청
    it('repairRequest: ', async() => {
        await carhub.methods.authUser('P001','이고객','I001','삼성화재')
                    .send({from: accounts[0], gas:1000000});
        await carhub.methods.accRequest('11가1234','010-111-1111','I001','삼성화재','사고내용...','20181101')
                    .send({from: accounts[0], gas:1000000});
        const accReqNo = await carhub.methods.getAccReqNo().call();
        console.log('repairRequest.accReqNo: ', accReqNo);

        await carhub.methods.repairRequest(accReqNo, 'C001', '삼성센터')
                    .send({from: accounts[0], gas:1000000});
        const status = await carhub.methods.getCarInfoStatus(accReqNo).call();
        assert.equal(status, "20");
    })
});